/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HU1Registro;

import general.Persona;

/**
 *
 * @author maria
 */
public class Huesped extends Persona {
    String email;
    int celular;

    public Huesped() {
    }

    public Huesped(String nombre, String id, String email, int celular) {
        super(nombre, id);
        this.email = email;
        this.celular = celular;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getCelular() {
        return celular;
    }

    public void setCelular(int celular) {
        this.celular = celular;
    }
    
}