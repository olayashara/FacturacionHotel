/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HU1Registro;

import general.Lectura;
import general.Persona;
import java.util.ArrayList;

/**
 *
 * @author maria
 */
public class Grupo extends Persona{
    static Lectura lectura = new Lectura();
    static ArrayList<Persona> grupo = new ArrayList<>();
    
    public void ingresarPersona() {
        int nroPersonas = lectura.leeryValidarInt("�De cu�ntas personas es el grupo?: ");
        
        for(int i = 0; i < nroPersonas; i++){
            Persona p1 = new Persona();
            p1.setName(lectura.leerString2("Ingrese el nombre de la persona: "));
            p1.setId(lectura.leerString("Ingrese el n�mero de identificaci�n: "));
//            p1.setOcupacion(lectura.leerString("Ingrese la ocupaci�n de la persona: "));
            
            grupo.add(p1);
            System.out.println("Persona a�adida con �xito");
           }
    }

    public ArrayList<Persona> getGrupo() {
        return grupo;
    }
    
    
}
