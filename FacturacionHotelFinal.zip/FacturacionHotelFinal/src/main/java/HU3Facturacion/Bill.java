/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HU3Facturacion;

import HU1Registro.Huesped;
import general.Persona;

/**
 *
 * @author maria
 */
public class Bill{
    private int billNo;
    private Huesped huesped;
    private Persona persona;
        
    public Bill(){
    }

    public Bill(int billNo, Huesped huesped) {
        this.huesped = huesped;
        this.billNo = billNo;
    }
    
    public Bill(int billNo, Persona persona) {
        this.persona = persona;
        this.billNo = billNo;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }
    
    public int getBillNo() {
        return billNo;
    }

    public void setBillNo(int billNo) {
        this.billNo = billNo;
    }

    public Huesped getHuesped() {
        return huesped;
    }

    public void setHuesped(Huesped huesped) {
        this.huesped = huesped;
    }
    
    @Override
    public String toString() {
        return "Factura nro " + billNo + " para el cliente " + 
                huesped.getName()+ " con identificaci�n " + huesped.getId() ;
    }
    
    public String toString2(Persona persona) {
        return "Factura nro " + billNo + " para el cliente " + 
                persona.getName()+ " con identificaci�n " + persona.getId() ;
    }
    
}
