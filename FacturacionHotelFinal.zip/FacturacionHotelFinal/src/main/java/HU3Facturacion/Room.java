/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HU3Facturacion;

/**
 *
 * @author maria
 */
public class Room {
    public int nroHabitacion;
    public int location;
    public int precio;
    public int tiempo;
    public int da�os;
    
    public Room() {
    }

    public Room(int nroHabitacion,int location, int precio, int tiempo, int da�os) {
        this.nroHabitacion = nroHabitacion;
        this.location = location;
        this.precio = precio;
        this.tiempo = tiempo;
        this.da�os = da�os;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getTiempo() {
        return tiempo;
    }

    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    public int getNroHabitacion() {
        return nroHabitacion;
    }

    public int getDa�os() {
        return da�os;
    }

    public void setDa�os(int da�os) {
        this.da�os = da�os;
    }

    public void setNroHabitacion(int nroHabitacion) {
        this.nroHabitacion = nroHabitacion;
    }

    public int getLocation() {
        return location;
    }

    public void setLocation(int location) {
        this.location = location;
    }
@Override
    public String toString() {
        return "Habitaci�n nro: " + nroHabitacion +" \n ocupada en un tiempo de: " 
                + tiempo + " noche(s) \n con tarifa por noche de: " + precio/tiempo + " pesos \n subtotal: " + precio;
    }
    
}