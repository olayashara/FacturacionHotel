/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HU3Facturacion.payment;

import general.Lectura;

/**
 *
 * @author maria
 */
public class Tarjeta implements Payment {
    static Lectura lectura = new Lectura();
    public boolean paid = true;

    @Override
    public void pay() {
        System.out.println("Acerque la tarjeta al dat�fono");
    }

    @Override
    public void verificarPago(double costoTotal) {
        double saldo = lectura.leeryValidarInt("Saldo disponible: ");
            
        if (saldo < costoTotal){
            System.out.println("Saldo insuficiente");
            paid = false; 
        } else{}
            
    }
    
    public boolean isPaid() {
        return paid;
    }

    @Override
    public void printReceipt(double costoTotal) {
        
    }
    
}
