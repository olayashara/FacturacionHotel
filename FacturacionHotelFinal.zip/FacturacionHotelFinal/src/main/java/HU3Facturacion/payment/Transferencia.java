/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HU3Facturacion.payment;

import general.Lectura;

/**
 *
 * @author maria
 */
public class Transferencia implements Payment{
    static Lectura lectura = new Lectura();
    private int nroReferencia;
    public boolean paid = true;
              
    @Override
    public void pay(){
        System.out.println("""
                           Datos para transferencia (cuenta de destino): 
                            Nro de cuenta: 01945622800
                            Tipo de cuenta: Ahorros Bancolombia
                            NIT: 099856412""");
    }
    
    @Override
    public void verificarPago(double costoTotal) {
        char verificar = lectura.leerChar("�Se realiz� la transferencia? (s/n) ");
        if (verificar == 's' || verificar == 'S'){
            nroReferencia = lectura.leeryValidarInt("Nro de referencia de la transferencia realizada: M");
        } else {
            System.out.println("Tr�mite cancelado");
            paid = false;
        }
    }

    @Override
    public void printReceipt(double costoTotal) {
        System.out.println("Valor transferido: " + costoTotal + 
                "\n Nro de referencia:  M" + nroReferencia);
    }
    
    public boolean isPaid() {
        return paid;
    }
    
}
