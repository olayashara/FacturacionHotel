/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package HU3Facturacion.payment;

/**
 *
 * @author maria
 */
public interface Payment {
    public void pay();
    public void printReceipt(double costoTotal);
    public void verificarPago(double costoTotal);
}
