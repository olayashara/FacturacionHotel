/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package general;

import HU1Registro.Registro;
import HU3Facturacion.Facturacion;
import HU3Facturacion.FacturacionGrupal;
import HU3Facturacion.payment.*;

/**
 *
 * @author maria
 */
public class Tramites {
    static Lectura lectura = new Lectura();
    static Facturacion fact = new Facturacion();
    static Registro reg = new Registro();
    static FacturacionGrupal factG = new FacturacionGrupal();
    
    
    public static void main(String[] args) {
        int option;
        
        
        do{
            
            option = lectura.leeryValidarInt2("""
                                              Bienvenido/a, �qu� tr�mite desea realizar?
                                                A�adir un nuevo cliente al sistema (0)
                                                Realizar una facturaci�n a un cliente existente (1)
                                                Realizar una facturaci�n a un grupo de personas (2)
                                                Salir del men� (3)
                                              Ingrese el n�mero seg�n corresponda: """ , 0,2);
            
            switch (option) {
            case 0 -> reg.registrarDatos();
                
            case 1 -> {
                if(fact.clienteExistente()){
                    fact.recopilacionDatos();
                    pagar(fact);
                } else {
                    System.out.println("Cliente no existente. Intente registrarlo como nuevo cliente");
                    break;
                }
                }
                
            case 2 -> {
                reg.registrarDatos1();
                factG.recopilacionDatos();
                pagar(factG);
                }
            
            case 3 -> System.out.println("Gracias por usar nuestro programa, que tenga un lindo d��a");
                
            default -> {
                }
        }
            
        }while(option != 2);
    }
    
    public static int intentarNuevoPago(){
        int pago = lectura.leeryValidarInt2("""
                                        �Intentar con otro medio de pago?
                                            Efectivo (0)
                                            Transferencia (1)
                                            Tarjeta(2)
                                            Cancelar tr�mite (3)
                                        """, 0, 3);
        if (pago == 3){
            System.out.println("Gracias por usar nuestro programa, que tenga un lindo d��a");
            return 3;
        }else {
            return (pago);
        }
    }
    
    public static void pagar(Facturacion fact){
        int pago;       
        pago = lectura.leeryValidarInt2("""
                                        �Qu� forma de pago desea implementar?
                                            Efectivo (0)
                                            Transferencia (1)
                                            Tarjeta (2)
                                                """, 0, 2);
        do {
        while (pago == 0){
            Efectivo cash = new Efectivo();                 
            fact.payBill(cash);
            fact.verificarPago(cash);

            if (cash.isPaid()){
                fact.imprimirFactura(cash);
                break;
            } else {
                pago = intentarNuevoPago();
                    if (pago == 3)
                    {break;}
            }
        }
                
        while (pago == 1){
            Transferencia transferencia = new Transferencia();

            fact.payBill(transferencia);
            fact.verificarPago(transferencia);

            if (transferencia.isPaid()){
                fact.imprimirFactura(transferencia);
                break;
            } else {
                pago = intentarNuevoPago();
                if (pago == 3)
                    {break;}
            }
        }
                
        while (pago == 2){
            int tipoTarjeta = lectura.leeryValidarInt2("(0) Cr�dito \n(1) D�bito \n", 0, 1);

            if (tipoTarjeta == 0){
                Credito cardC = new Credito();
                fact.payBill(cardC);
                cardC.nroCuotas(fact.getCostoTotal());
                cardC.verificarPago();

                if (cardC.isPaid()){
                    fact.imprimirFactura(cardC);
                    break;
                } else {
                    pago = intentarNuevoPago();
                    if (pago == 3)
                        {break;}
                }

            } else if (tipoTarjeta == 1){
                Tarjeta cardD = new Debito();
                fact.payBill(cardD);
                fact.verificarPago(cardD);

                if (cardD.isPaid()){
                    fact.imprimirFactura(cardD);
                    break;
                } else {
                    pago = intentarNuevoPago();
                    if (pago == 3)
                        {break;}
                }
            }
        }
        }while(pago != 3);
    }
}
